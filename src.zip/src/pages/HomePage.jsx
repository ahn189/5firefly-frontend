import HeroSection from '../components/HeroSection';
function HomePage() {
  return (
    <div>
      <HeroSection />
    </div>
  );
}
export default HomePage;